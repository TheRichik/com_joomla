<?php

defined('_JEXEC') or exit();

class RichControllerList extends JControllerForm
{
	/*public function add() { как пример смени макета 
		JFactory::getApplication()->input->set('layout','new');
		parent::add();
	}*/

	public function edit(){
		parent::edit();
	}
/*	public function delete(){
		parent::delete();
	}*/
		public function getModel ($name = 'List', $prefix = 'RichModel', $config = [])
	{
		return parent::getModel($name,$prefix,$config);
	}
}

?>