<?php

defined('_JEXEC') or exit();

class RichControllerLists extends JControllerAdmin
{
	public function getModel ($name = 'List', $prefix = 'RichModel', $config = [])
	{
		return parent::getModel($name,$prefix,$config);
	}

	

}