<?php

defined('_JEXEC') or exit();

class RichTableList extends JTable
{
	public function __construct($db) {
		parent::__construct('jom_rich_question', 'id', $db);
	}

}


?>