<?php

defined('_JEXEC') or exit();

class RichController extends JControllerLegacy 
{
	protected $default_view = "lists";
}

?>