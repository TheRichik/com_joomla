<?php

defined('_JEXEC') or exit();

//Создает екземпляр класа
$controller = JControllerLegacy::getInstance('Rich');

//выбираем значение строки get
$input = jFactory::getApplication()->input;

//выполняем действие и используем такс
$controller->execute($input->getCmd('task','display'));

$controller->redirect();

?>