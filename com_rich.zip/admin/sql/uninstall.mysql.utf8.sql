DROP TABLE IF EXISTS `jom_rich_question`;
