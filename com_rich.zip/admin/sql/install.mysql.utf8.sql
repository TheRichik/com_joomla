DROP TABLE IF EXISTS `jom_rich_question`;

CREATE TABLE IF NOT EXISTS `jom_rich_question` (
	`id` int(11) NOT NULL AUTO_INCREMENT,
	`question` varchar(255) NOT NULL,
	`published` tinyint(4) DEFAULT NULL,
	`option1` varchar (255) NOT NULL,
	`option2` varchar (255) NOT NULL,
	`option3` varchar (255) NOT NULL,
	`answer` varchar (255) NOT NULL,
	PRIMARY KEY(`id`)
	)ENGINE=MyISAM DEFAULT CHARSET=utf8;

