<?php
defined('_JEXEC') or exit();

#JHtml::_('formbehavior.chosen','text');

?>

<form action="<? echo JRoute::_('index.php?option=com_rich&layout=edit&id='.(int) $this->item->id)  ?>" method="POST" id="adminForm" name="adminForm" class="form-validate">
	
	<? echo $this->form->renderFieldset('basic'); ?>
	
	<!-- <? //echo $this->form->getField('id')->renderField() ?> -->
	<input type="hidden" name="task" value="list.edit">

	<? echo JHtml::_('form.token'); ?>

</form>

