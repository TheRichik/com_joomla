<?php

defined('_JEXEC') or exit();

class RichViewList extends JViewLegacy 
{
	protected $form;
#	protected $item;

	public function display($tpl = null){

		$this->form = $this->get('Form'); // обращение к модели
		#print_r($this->form);

		$this->item = $this->get('Item');
		 #print_r($this->item);

		$this->addToolBar();
		

		parent::display($tpl);
	}

	protected function addToolBar() {

		$isnew = ($this->item->id == 0);

		if ($isnew) {
			$title = 'Добавление теста';
		}
		else {
			$title = 'Редаткирование теста';
		}

		JToolBarHelper::title($title);
		JToolBarHelper::apply('list.apply');
		JToolBarHelper::save('list.save');
		JToolBarHelper::cancel('list.cancel');

	}

	



}

?>
