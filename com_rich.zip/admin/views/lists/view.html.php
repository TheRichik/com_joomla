<?php

defined('_JEXEC') or exit();

class RichViewLists extends JViewLegacy
{
	protected $items;
	protected $pagination;

	


	public function display($tpl = null){
		
		$this->addToolBar();

		$this->items = $this->get('items'); // getItems Model
		
		$this->pagination = $this->get('Pagination');


	
		parent::display($tpl);

	}
	// проблема с переводом 
	//(JText::_('COM_RICH_LISTS'))-? не переводит константу;

	protected function addToolBar(){
		JToolBarHelper::title('Список тестов');
		JToolBarHelper::addNew('list.add','Создать тест');
		JToolBarHelper::editList('list.edit','Изменить тест');
		JToolBarHelper::deleteList('Удалить тест?','lists.delete');
		JToolBarHelper::publish('lists.publish');
		JToolBarHelper::unpublish('lists.unpublish');
	}

}

?>
