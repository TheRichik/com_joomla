<?php

defined('_JEXEC') or exit();

?>

<form action="<? echo JRoute::_('index.php?option=com_rich&view=lists') ;?>" method="POST" name="adminForm" id="adminForm">
	
	<table class="table table-striped table-hover">
	<!-- header -->
		<thead>
				<th width="1%">Номер вопроса</th>
				<th width="2%"> <? echo JHtml::_('grid.checkall') ;?> </th>
				<th width="10%">Вопрос</th>
				<th width="10%">Вариант 1</th>
				<th width="10%">Вариант 2</th>
				<th width="10%">Вариант 3</th>
				<th width="10%">Ответ</th>
				<th width="3%">Опубликовано</th>
				<th width="1%"> id </th>
			
		</thead>

		<tbody>

			<?if (!empty($this->items)):?>

			<? $i=1;?>
				<? foreach($this->items as $key=>$item):?>
					<tr>
				
						<td> <? echo $i++?> </td>
						<td> <? echo JHtml::_('grid.id', $key, $item->id) ;?> </td>
						<td> 
							<? $link = JRoute::_('index.php?option=com_rich&task=list.edit&id='.$item->id); ?> 
								<!-- <a href="<?// echo $link?>"><?// echo $item->question ;?></a> -->
								<? echo JHtml::_('link',$link, $item->question); ?>
						 </td>
						<td><?echo $item->option1?></td>
						<td><?echo $item->option2?></td>
						<td><?echo $item->option3?></td>
						<td><?echo $item->answer?></td>
						<td><?echo JHtml::_('jgrid.published',$item->published,$key,'lists.'); ?> </td>
						
						<td><?echo $item->id?></td>
					</tr>
				<? endforeach ;?>
			<? endif ;?>

		</tbody>

		<tfoot  >
		
		<tr>
		<td colspan='5'>
			<div style="float: left"><?echo $this->pagination->getListFooter();?></div>
			<!-- <div style="float: right">Показать-<?//echo $this->pagination->getLimitBox();?></div> -->

		</td>
		</tr>
		
		</tfoot>
	</table>


	<input type="hidden" name="task" value="" />
	<input type="hidden" name="boxchecked" value="0" /> 
	<? echo JHtml::_('form.token') ?>

</form>