<?php

defined('_JEXEC') or exit();

class RichModelLists extends JModelList
{
	protected function getListQuery() {
		//Вызов родителя функцией где работает драйвера с бд и его обьект мы возврощаем
		$query = parent::getListQuery();

		$query->select('id, question, published,option1,option2,option3,answer');
		$query->from('jom_rich_question');
		$query->order('id');
	
		return $query;
	}

}