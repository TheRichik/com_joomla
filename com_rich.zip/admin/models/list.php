<?php

defined('_JEXEC') or exit();

class RichModelList extends JModelAdmin
{
	// отображение форми или загрузка ее
	public function getForm($data = [], $loaddata = true) {

		$form = $this->loadForm($this->option.'list', 'testlist', ['control'=>'jform','load_data'=>$loaddata] );

		if(empty($form)){
			return FALSE;
		}

		return $form;
	}
	// запись в бд через таблицу
	public function getTable($type = 'List', $prefix = 'RichTable', $config = []) {
		return JTable::getInstance($type,$prefix,$config);
	}

	public function loadFormData() {
		//доступ к сесии и ее данних что то не виходит
		#$data = JFactory::getApplication()->getUserState('com_rich.edit.list.data');
		//print_r($data);
		
		#if(empty($data)){
			$data = $this->getItem();
			#print_r($data);
		# }
		
		return $data;
	}



}

?>