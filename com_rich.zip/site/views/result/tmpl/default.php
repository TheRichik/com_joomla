<?
	defined('_JEXEC') or exit();

$count = 0;
$answer=0;
	foreach ($this->items as $key => $item) 
	{
		if ($item->published == 1) 
		{
			$count++;
		}
		foreach ($_POST as $key => $value) 
		{
			if ($value == $item->answer) 
			{
				$answer++;
			}
		}
	}




$result=$answer/($count/100); 
  

?>

<h1 align="center">Поздровляю</h1>
<h3 align="center">Количество правильних ответов <?echo $answer.' из '.$count.' Всего '.$result.'%';?></h3>
<h5 align='center'><a href="<?JRoute::_('richikjoomla/index.php?');?>">На главную</a></h5>