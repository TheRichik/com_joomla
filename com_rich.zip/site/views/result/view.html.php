<?
defined('_JEXEC') or exit();

class RichViewResult extends JViewLegacy
{
	protected $items;
	public function display($tpl = null)
	{
		$items = $this->get('Items');
		$this->items = $items;
		//print_r($_POST);
		//print_r($items);

		
		parent::display($tpl);
	}
}