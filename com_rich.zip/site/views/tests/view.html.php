<?
defined('_JEXEC') or exit();

class RichViewTests extends JViewLegacy
{
	protected $items;
	protected $pagination;

	public function display($tpl = null)
	{

		$items = $this->get('Items');
		$this->pagination = $this->get('Pagination');// created some pages from test in progress 

		$this->items = $items;

		/*echo '<pre>';
		print_r($this->pagination);
		echo "</pre>";*/
		parent::display($tpl);
		
	}
}

?> 