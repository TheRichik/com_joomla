<? 
defined('_JEXEC') or exit();


?>
<form method="POST" action="<? echo JRoute::_('index.php?option=com_rich&view=result') ;?>">
<? if(!empty($this->items)):?>
	<h1 align="center">Тесты</h1>

	<?$i=1?>
	<!-- Тестовый вариант отображение тестов -->
	
	<? foreach($this->items as $key=>$item) :?>



			
	
	<h3><?echo $i++.') ';echo $item->question?></h3>

	<?if(!empty($item->option1)):?>
		<label><input type="radio" name="answers<?echo$i;?>" value="<?echo $item->option1?> "><?echo $item->option1?></label><br>
	<?endif?>

	<?if(!empty($item->option2)):?>
		<label><input type="radio" name="answers<?echo$i;?>" value="<?echo $item->option2?> "><?echo $item->option2?></label><br>
	<?endif?>

	<?if(!empty($item->option3)):?>
		<label><input type="radio" name="answers<?echo$i;?>" value="<?echo $item->option3?> "><?echo $item->option3?></label><br>
	<?endif?>

	<?if(!empty($item->answer)):?>
		<label><input type="radio" name="answers<?echo$i;?>" value="<?echo $item->answer?>" ><?echo $item->answer?></label><br>
	<?endif?>
	
	

	<hr>
	<tr>
		<td><? //echo $this->pagination->getRowOffset($key)?></td>
		<?//echo $this->pagination->getPagesCounter($key);?>
	</tr>
	<? endforeach;?>

<input type="submit" name="ok">

<? endif ?>

</form>

