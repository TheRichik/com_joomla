<?
defined('_JEXEC') or exit();

class RichModelResult extends JModelList
{
	protected function getListQuery()
	{
		$query = parent::getListQuery();
		$query->select('id,published,answer');
		$query->where('published=1');
		$query->from('jom_rich_question');
		

		return $query;
	}
}
?>