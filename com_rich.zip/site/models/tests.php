<?
defined('_JEXEC') or exit();

class RichModelTests extends JModelList
{
	

	protected function getListQuery()
	{
		$query = parent::getListQuery();
		$query->select('question,option1,option2,option3,answer');
		$query->where('published=1');
		$query->from('jom_rich_question');
		

		return $query;
	}

	
}
?>