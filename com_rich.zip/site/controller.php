<?
defined('_JEXEC') or exit();

class RichController extends JControllerLegacy
{

}