<?
defined('_JEXEC') or exit();

$controller = JControllerLegacy::getInstance('Rich');

$input = JFactory::getApplication()->input;

$controller->execute($input->getCmd('task'));

$controller->redirect();

?>